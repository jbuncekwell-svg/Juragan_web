module.exports = {
    version: "4.0",
    ownerId: 6736986837,
    namaBot: "𝙱𝙾𝚃 𝙲𝙴𝙺 𝙱𝙸𝙾 𝙰𝙽𝙶𝙺𝙰𝚂𝙰",
    usernameOwner: "@angkasanyabobo",
    telegramBotToken: "8284071488:AAHrdTaykMhPtd8SVLSOvNkxh1jN6573wUE",
    sessionName: "session",
    portVps: "1308",
    ipVps: "http://167.172.74.119",
    message: {
        owner: `🚫 Khusus Owner Jangan Spam!`,
        wait: `⏳ Otw Tunggu Sebentar...`,
        error: `⚠️ error. Coba lagi nanti.`,
        waNotConnected: `⚠️ Tidak Ada Whatsapp Yang Terhubung /pairing Untuk Menghubngkan Ke Whatsapp.`
    },
    settings: {
        namabot: "Cek Bio By Angkasa",
        footer: "Powered By Angkasa",
        cekBioBatchSize: 20
    }
};